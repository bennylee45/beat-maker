# beat-maker

Create sounds with clicks.

### Usage:
1. Clone this repository.
2. Open the index.html file with a live server.

### Author:
Jacob C.