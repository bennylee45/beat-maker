html5-audio-editor
==================

A small audio editor written in html5 and javascript without usage of external plugins.


You need the latest build of Google Chrome or the nightly build for Safari. Firefox is not supported yet.

I'm working with Chrome Version 20.0.1132.47 beta and have to start Chrome with the parameter "--allow-file-access-from-files". You need this to start the web application from the local filesystem.

==================

If you want to see this application in action, go to http://plucked.de

